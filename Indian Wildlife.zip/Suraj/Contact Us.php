<html>
 <head>
  <title>Contact us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
  <style>
   @font-face
     {
       font-family:Colonna;
       src:url(COLONNA.TTF);
     }
	 @font-face
     {
       font-family:Footlight;
       src:url(FTLTLT.TTF);
     }
	 @font-face
     {
       font-family:Book;
       src:url(BKANT.TTF);
     }
     header
     {
       background-color:black;
  	 height:100px;
  	 position:relative;
  	 width:1140px;
  	 margin-left:105px;
  	 color:white;
  	 font-size:16px;
  	 text-align:left;
	 border: 2px solid black;
	 border-radius:7px;
     }
	 ul
     {
       text-align:right;
  	   display: inline;
       margin-top:10px;
       padding: 3px 4px 3px 4px;
       list-style: none;
	   font-family:Footlight;
	   font-size:18px;
     }
     ul li
     {
       display: inline-block;
       position: relative;
  	   padding: 6px 8px 6px 8px;
       background:black;
  	   color:white;
     }
     ul li:hover 
     {
       background: orange;
       color: #000000;
     }
     ul li ul
     {
       position:absolute;
  	   top:22px;
       left:0;
       width:100px;
       display:none;
       visibility:hidden;
     }
     ul li ul li
     { 
       background: black;
       display:block; 
       color: white;
     }
     ul li:hover ul
     {
      display: block;
  	  padding-left:0px;
      opacity: 1;
  	  z-index:3;
      visibility: visible;
     }
     .donate
     {
  	 border:1px solid black;
  	 border-radius:2px;
     }
     ul#nav
	 {
		 float:right;
		 color:white;
		 background:black;
		 font-size:20px;
		 margin-top:-50px;
		 padding-top:0px;
	 }
	 ul#nav li
	 {
	   display: inline-block;
       position: relative;
  	   padding: 2px 2px 2px 2px;
       background:black;
  	 }
	 h1
	 {
		 font-family:Colonna;
		 font-size:40px;
	 }
     #logo
     {
       z-index:3;
       text-align:left;
       position:absolute;
  	   width:80px;
  	   height:80px;
  	   margin-top:10px;
  	   margin-left:50px;
     }   
     a
	 {
		 color:orange;
	 }
	 a:hover
	 {
		 color:white;
	 }
	 a:visited
	 {
		 color:orange;
	 }
     #contact
	 {
		 padding-left:70px;
	     padding-top:50px;
	     background:black;
		 margin-left:105px;
		 width:1140px;
		 height:566px;
		 margin-top:10px;
		 border: 2px solid black;
		 border-radius:7px;
	     font-family:Book;
	     font-size:18px;
	 }
	 table,tr,td
     {
		 color:white;
		 width:450px;
		 border:1px solid black;
     }
     tr
     {
		 height:50px;
     }
     .textbox 
     { 
		 background: white; 
		 border: 1px double #DDD; 
		 border-radius: 5px; 
		 box-shadow: 0 0 5px #333; 
		 color: #666; 
		 outline: none; 
		 height:25px; 
		 width: 200px; 
     } 
	 .textarea
     {
		 background: white; 
		 border: 1px double #DDD; 
		 border-radius: 5px; 
		 box-shadow: 0 0 5px #333; 
		 color: #666; 
		 outline: none; 
     } 
     .button
     {
		 background:#9ceded;
		 border: 1px double #DDD; 
		 border-radius: 5px; 
		 box-shadow: 0 0 5px #333; 
		 color: #666; 
		 outline: none; 
		 height:25px; 
		 width:100px;
     }
	 body
     { 
		 background-color:#f2d7ac;
		 position:relative;
     }
  </style>
 </head>
 <body>
  <header>
   <a href="home.php" >
   <img  id="logo" src="logo.png" />
   </a>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   <ul> 
    <li>About Us
	 <ul>
	  <li><a href="history.html">History</li>
	  <li><a href="work.html">Our Work</li>
	  <li><a href="Contact Us.php">Contact</a></li>
	 </ul>
	</li>
	<li class="donate"><a href="Donate.php" style="color: white">Donate</a></li>
   </ul>
   <h1 align="center" style="color:orange;"><a href="home.php">Indian Wildlife</a></h1>
   <ul id="nav">
    <li><a href="Blog.php">Blog</a></li> &nbsp; &nbsp;
	<li><a href="Gallery.php">Gallery</a></li> &nbsp; &nbsp;
   </ul>
   </header>
 
  <script>
   function myfunc()
   {
     var username= document.getElementById("uname").value;
     var pat1= /^[A-Za-z0-9_]+$/;
	 if(pat1.test(username)==false)
     {
	   alert("Enter correct Username");
	 }
   }
  </script>
  
  <section id="contact">
   <form action="Contact Us.php" method="POST">
    <table cellpadding="10" cellspacing="100" align="center">
	 
	 <tr>
	  <td>Username:</td>
	  <td><input type="text" name="username" placeholder="Username" id="uname" class="textbox" required>
	 </tr>
	
     <tr>
	  <td>Email:</td>
	  <td><input type="email" name="email" placeholder="Email" id="email" class="textbox" required>
	 </tr>
	 
	 <tr>
	  <td>Password:</td>
	  <td><input type="password" name="password" placeholder="Password" id="password" class="textbox" required>
	 </tr>
    
	 <tr>
	  <td>Feedback:</td>
	  <td><textarea name="feedback" id="feedback" class="textarea" placeholder="Feedback" rows="10" cols="40" required></textarea>
	 </tr>
     
     <tr>
	  <td> </td>
      <td align="center"><input type="submit" onclick="myfunc()" value="Submit" name="submit" class="button"></td>
	 </tr>
	 
    </table>
   </form>
   <?php
   if(isset($_POST['submit']))
   {
      $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
	  $u=$_POST['email'];
      $p=$_POST['password'];
	  $uname=$_POST['username'];
	  $headers="From" . $u;
	  $count=0;
      $sql="select * from users where Email='$u' and Password='$p'";
      $res=mysql_query($sql);
      while($row=mysql_fetch_array($res))
      {
        $count++;
      } 
      if($count==1)
      {
 		$to="sshreyeshi@gmail.com";
	    $message=$_POST['feedback'];
	    $body ="Person $uname submitted a message: $message";
	    $subject="FeedBack From Website";
		mail($to, $subject, $body, $headers);
		$sql=mysql_query("insert into contact values(' ','$uname','$u','$message')");
		echo "<script> alert('Thank you for contacting us! Your mail has been sent. We will get back to you soon!!');  </script>";
 	  }
 	  else
 	  {
 	  	echo "<script> alert('Incorrect login credentials!');  </script>";
 	  }
    }
   ?>
  </section>
 </body>
</html>
<html>
 <head>
  <title>Blog</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <style>
   @font-face
     {
       font-family:Colonna;
       src:url(COLONNA.TTF);
     }
	 @font-face
     {
       font-family:Footlight;
       src:url(FTLTLT.TTF);
     }
	 @font-face
     {
       font-family:Book;
       src:url(BKANT.TTF);
     }
   header
     {
       background-color:black;
  	 height:100px;
  	 position:relative;
  	 width:1140px;
  	 margin-left:105px;
  	 color:white;
  	 font-size:16px;
  	 text-align:left;
	 border: 2px solid black;
	 border-radius:7px;
	 }
	 a
	 {
		 color:orange;
	 }
	 a:hover
	 {
		 color:white;
	 }
	 a:visited
	 {
		 color:orange;
	 }
     ul
     {
       text-align:right;
   	   display: inline;
       margin-top:10px;
       padding: 3px 4px 3px 4px;
       list-style: none;
	   font-family:Footlight;
	   font-size:18px;
     }
     ul li
     {
       display: inline-block;
       position: relative;
  	   padding: 6px 8px 6px 8px;
       background:black;
  	   color:white;
     }
     ul li:hover 
     {
       background: orange;
       color: #000000;
     }
     ul li ul
     {
       position:absolute;
  	   top:22px;
       left:0;
       width:100px;
       display:none;
       visibility:hidden;
     }
     ul li ul li
     { 
       background: black;
       display:block; 
       color: white;
     }
     ul li:hover ul
     {
      display: block;
      padding-left:0px;
      opacity: 1;
  	  z-index:3;
      visibility: visible;
     }
     .donate
     {
  	 border:1px solid black;
  	 border-radius:2px;
     }
     ul#nav
	 {
		 float:right;
		 color:white;
		 background:black;
		 font-size:20px;
		 margin-top:-50px;
		 padding-top:0px;
	 }
	 ul#nav li
	 {
	   display: inline-block;
       position: relative;
  	   padding: 2px 2px 2px 2px;
       background:black;
  	   
	 }
	 h1
	 {
		 font-family:Colonna;
		 font-size:40px;
	 }
     #logo
     {
       z-index:3;
  	   text-align:left;
  	   position:absolute;
  	   width:80px;
  	   height:80px;
  	   margin-top:10px;
  	   margin-left:50px;
     }  
   #newspost
   {
     position:relative;
	 background:black;
	 color:white;
	 float:left;
	 margin-left:105px;
	 margin-top:-5px;
	 width:1140px;
	 padding-left:10px;
	 padding-top:5px;
	 padding-bottom:5px;
	 padding-right:10px;
	 border: 2px solid black;
	 border-radius:7px;
	 font-family:Book;
	 font-size:18px;
   }
   #imagesec
   {
     position:relative;
	 background:black;
	 color:white;
	 float:right;
	 width:300px;
	 margin-right:121px;
	 margin-top:1px;
	 padding-top:8px;
	 padding-left:5px;
	 padding-bottom:8px;
	 padding-right:5px;
   }
   body
   { 
     background-color:#f2d7ac;
	 position:relative;
   }
  </style>
 </head>
 <body link="white">
  <header>
   <a href="home.php" >
   <img  id="logo" src="logo.png" />
   </a>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   <ul> 
    <li>About Us
	 <ul>
	  <li><a href="history.html">History</li>
	  <li><a href="work.html">Our Work</li>
	  <li><a href="Contact Us.php">Contact</a></li>
	 </ul>
	</li>
	<li class="donate"><a href="Donate.php" style="color: white">Donate</a></li>
   </ul>
   <h1 align="center" style="color:blue"><a href="home.php">Indian Wildlife</a></h1>
   <ul id="nav">
    <li><a href="Blog.php">Blog</a></li> &nbsp; &nbsp;
	<li><a href="Gallery.php">Gallery</a></li> &nbsp; &nbsp;
   </ul>
   </header>
  
  <!--<section id="imagesec">
  
  <?php
   $conn=mysql_connect("localhost","root","");
   mysql_select_db("wildlife",$conn);
   $sql=mysql_query("select * from blog");
   while($row=mysql_fetch_array($sql))
   {
    $n1=$row['Name'];
    $n2=$row['News'];
    echo "<h2>".$n1."</h2><br><br><h3>.".$n2."</h3>";
   }
  ?> 
  </section> -->
  
  <section id="newspost">
    <h2 align="center">Current Blogs </h2>  
    <br> 
    <?php
     $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
    $sql=mysql_query("select * from blog");
   while($row=mysql_fetch_array($sql))
   {
    $n1=$row['Title'];
    $n2=$row['News'];
    echo "<h4>".$n1."</h4>"."<h5>".$n2."</h5>";
    echo "<br>";
   }

   echo "<br>";
   echo "<h3><a href='acblog.php'>Click here to Post a new blog </a></h3>";  
  ?>
  </section>
  
 <body>
</html>
  <html>
   <head>
    <title>Indian Wildlife</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <style>
	 @font-face
     {
       font-family:Colonna;
       src:url(COLONNA.TTF);
     }
	 @font-face
     {
       font-family:Footlight;
       src:url(FTLTLT.TTF);
     }
	 @font-face
     {
       font-family:Book;
       src:url(BKANT.TTF);
     }
     header
     {
       background-color:black;
  	 height:100px;
  	 position:relative;
  	 width:1140px;
  	 margin-left:105px;
  	 color:white;
  	 font-size:16px;
  	 text-align:left;
	 border: 2px solid black;
	 border-radius:7px;
     }
	 ul
     {
       text-align:right;
  	   display: inline;
       margin-top:10px;
       padding: 3px 4px 3px 4px;
       list-style: none;
	   font-family:Footlight;
	   font-size:18px;
     }
     ul li
     {
       display: inline-block;
       position: relative;
  	   padding: 6px 8px 6px 8px;
       background:black;
  	   color:white;
     }
     ul li:hover 
     {
       background: orange;
       color: #000000;
     }
     ul li ul
     {
       position:absolute;
  	   top:22px;
       left:0;
       width:100px;
       display:none;
       visibility:hidden;
     }
     ul li ul li
     { 
       background: black;
       display:block; 
       color: white;
     }
     ul li:hover ul
     {
      display: block;
  	  padding-left:0px;
      opacity: 1;
  	  z-index:3;
color:white;
      visibility: visible;
     }
     .donate
     {
  	 border:1px solid black;
  	 border-radius:2px;
     }
     ul#nav
	 {
		 float:right;
		 color:white;
		 background:black;
		 font-size:20px;
		 margin-top:-50px;
		 padding-top:0px;
	 }
	 ul#nav li
	 {
	   display: inline-block;
       position: relative;
  	   padding: 2px 2px 2px 2px;
       background:black;
  	 }
	 h1
	 {
		 font-family:Colonna;
		 font-size:40px;
	 }
     #logo
     {
       z-index:3;
       text-align:left;
       position:absolute;
  	   width:80px;
  	   height:80px;
  	   margin-top:10px;
  	   margin-left:50px;
     }   
     .carousel-inner > .item > img,
     .carousel-inner > .item > a > img 
     {
        width: 100%;
        margin: auto;
     }
     #slider
     {
       position:relative;
  	   margin-top:-20px;
	 }
     #regist
     {
       position:relative;
  	 background:black;
  	 color:white;
  	 float:right;
  	 width:300px;
	 height:400px;
	 margin-top:10px;
  	 margin-right:104px;
  	 padding-left:15px;
  	 padding-top:20px;
  	 padding-bottom:20px;
  	 padding-right:15px;
	 border: 2px solid black;
	 border-radius:7px;
	 font-family:Book;
	 font-size:18px;
     }
     #popupbox
     {
       padding-top: 10px; 
  	 width: 250px; 
  	 padding-top:10px;
  	 padding-left:12px;
  	 padding-bottom:10px;
  	 padding-right:12px;
  	 color:black;
  	 height: 160px; 
  	 position: absolute; 
  	 background: #FBFBF0; 
  	 border: solid #000000 2px; 
  	 border-radius:4px;
  	 z-index: 9; 
  	 visibility: hidden; 
	 font-size:16px;
     }
     .login
     {
       background: white; 
       border: 1px double #DDD; 
       border-radius:2px; 
       box-shadow: 0 0 5px #000; 
       color: #666; 
       outline: none; 
     }
	 a
	 {
		 color:orange;
	 }
	 a:hover
	 {
		 color:white;
	 }
	 a:visited
	 {
		 color:orange;
	 }
	 .loginbutton
     {
       background:#cff7fa;
  	 border: 1px double #DDD; 
       border-radius: 5px; 
       box-shadow: 0 0 5px #333; 
       color: #666; 
       outline: none; 
       height:22px; 
  	 width:45px;
     }
	 #newshead
	 {
		 font-family:Book;
		 font-size:20px;
		 text-decoration:underline;
		 color:orange;
	 }
     #news
     {
       position:relative;
  	 background:black;
  	 color:white;
	 font-size:18px;
     height:400px;
  	 float:left;
	 margin-top:10px;
  	 margin-left:105px;
  	 width:839px;
  	 padding-left:10px;
  	 padding-top:10px;
  	 padding-bottom:5px;
  	 padding-right:10px;
	 overflow: scroll;
	 border: 2px solid black;
	 border-radius:7px;
	 font-family:Book;
	 }
     body
     { 
       background-color:#f2d7ac;
  	 position:relative;
     }
    </style>
  <script language="JavaScript" type="text/javascript">
   function login(showhide)
   {
    if(showhide == "show")
	{
      document.getElementById('popupbox').style.visibility="visible";
    }
	else if(showhide == "hide")
	{
      document.getElementById('popupbox').style.visibility="hidden"; 
    }
   }
  </script>
 </head>
 <body link="white">
  <header>
   <a href="home.php" >
   <img  id="logo" src="logo.png" />
   </a>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   <ul> 
    <li>About Us
	 <ul>
	  <li><a href="history.html">History</li>
	  <li><a href="work.html">Our Work</li>
	  <li><a href="Contact Us.php">Contact</a></li>
	 </ul>
	</li>
	<li class="donate"><a href="Donate.php" style="color: white">Donate</a></li>
   </ul>
   <h1 align="center" style="color:orange;"><a href="home.php">Indian Wildlife</a></h1>
   <ul id="nav">
    <li><a href="Blog.php">Blog</a></li> &nbsp; &nbsp;
	<li><a href="Gallery.php">Gallery</a></li> &nbsp; &nbsp;
	<li><a href="Endangered Species.html">Endangered Species</a></li> &nbsp; &nbsp;  
 </ul>
   </header>
  <section id="slider"> 
   <div class="container">
    <br>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
     <!-- Indicators -->
     <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
     </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
	 
	  <div class="item">
        <img src="lion2.jpg" alt="India" width="460px" height="345px">
      </div>
	
	<div class="item">
        <img src="peacock1.jpg" alt="India" width="460px" height="345px">
      </div>
	  	
      <div class="item">
        <img src="tiger.jpg" alt="Wildlife" width="460px" height="345px">
      </div>
	  
	   <div class="item">
        <img src="bird2.jpg" alt="Tiger" width="460px" height="345px">
      </div>

      <div class="item active">
        <img src="deer.jpg" alt="Wildlife" width="460px" height="345px">
      </div>
	  
     </div>

     <!-- Left and right controls -->
     <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
     </a>
     <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
     </a>
    </div>
   </div>
  </section>
  <section id="regist">
   <p>Register today to participate in our efforts and donate to non-profit organistions</p>
   &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp;
   <br />
   <a href="registration.php" >
   <center><img  id="regicon" src="reg.png" /></center>
   </a>   
   <br />
   <br />
   Already registered?
   <div id="popupbox"> 
    <form name="login" action="home.php" method="post">
      <p>
	    Username: &nbsp;
       <input type="email" name="username" size="14" class="login"/>
	   <br />
	   <br />
        Password: &nbsp;&nbsp;
	   <input name="password" type="password" size="14" class="login"/>
	   <br />
	     <center><input type="submit" name="submit" value="login" class="loginbutton"/></center>
	  </p>
    </form>
    <?php
     if(isset($_POST['submit']))
     {
      $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
      $u=$_POST['username'];
      $p=$_POST['password'];
      $count=0;
      $sql="select * from users where Email='$u' and Password='$p'";
      $res=mysql_query($sql);
      while($row=mysql_fetch_array($res))
      {
        $count++;
      } 
      if($count==1)
      {
        echo "<script> alert('Succesfull Login!');  </script>";
        header("Location:home.php");
      }
      else
      {
        echo "<script> alert('Incorect details!'); </script>";
        header("Location:home.php");
      }
    }
  ?>
	<p align="center"><a href="javascript:login('hide');">Close</a></p>
   </div> 
    <p><a href="javascript:login('show');">Login</a></p>
  </section>
  <section id="news">
   
   <p id="newshead" align="center">Current Blogs </p>  
    <br> 
    <?php
     $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
    $sql=mysql_query("select * from blog");
   while($row=mysql_fetch_array($sql))
   {
    $n1=$row['Title'];
    $n2=$row['News'];
    echo "<p>".$n1."</p>"."<p>".$n2."</p>";
    echo "<br>";
   }
  ?>
  </section>
  
 </body>
</html>
-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2015 at 06:50 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wildlife`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `News` varchar(5000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `Title`, `News`) VALUES
(14, 'aditi', 'This is the first news report'),
(16, 'Article', 'This article is about wildlife conservation.	   '),
(17, '', ''),
(18, 'Title1', 'Article   '),
(19, '', ''),
(20, 'Article1', 'New Article posted.	   ');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `feedback` varchar(5000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `username`, `email`, `feedback`) VALUES
(1, 'Aditi', 'aditi@123.com', 'Good'),
(2, 'Aditi', 'aditi@123.com', 'Good'),
(3, 'Bidisha', 'bidisha@123.com', 'Good'),
(4, 'Kavya', 'kavya@123.com', 'OKAY');

-- --------------------------------------------------------

--
-- Table structure for table `donation`
--

CREATE TABLE IF NOT EXISTS `donation` (
  `id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Amount` int(10) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation`
--

INSERT INTO `donation` (`id`, `Name`, `Phone`, `Email`, `Amount`, `Username`, `Password`) VALUES
(1, 'sankalp', 2147483647, 'sankalp@gmail.com', 10000, 'sankalp', 'sankalpmota'),
(2, 'suraj', 957454908, 'suraj@gmail.com', 56465, 'suraj', 'surajrishi'),
(3, 'suraj', 957454908, 'suraj@gmail.com', 56465, 'suraj', 'surajrishi'),
(4, 'asd', 2147483647, 'sankalp@gmail.com', 656546, 'sankalp', 'sankalpmota');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Name`, `Address`, `City`, `Gender`, `Phone`, `Email`, `Password`) VALUES
(2, 'suraj', 'vit', 'Bangalore', 'male', 2147483647, 'suraj@gmail.com', 'surajrishi'),
(4, 'Shreyeshi', 'ad', 'Bangalore', 'female', 2147483647, 'sshreyeshi@gmail.com', 'shreya@11'),
(5, 'Aditi', 'Fblock', 'Bangalore', 'female', 2147483647, 'aditi@123.com', 'aditi1234'),
(6, 'Shreyeshi', 'Vellore', 'Chennai', 'female', 2147483647, 'sshreyeshi@gmail.com', 'shreya21'),
(7, 'Bidisha', 'ad1', 'Bangalore', 'female', 1234567890, 'bidisha@123.com', 'bidisha123'),
(8, 'Kavya', 'add1', 'Bangalore', 'female', 2147483647, 'kavya@123.com', 'kavya123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`) COMMENT 'prim';

--
-- Indexes for table `donation`
--
ALTER TABLE `donation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `donation`
--
ALTER TABLE `donation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

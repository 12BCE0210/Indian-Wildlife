<html>
 <head>
  <title>Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <style>
   @font-face
     {
       font-family:Colonna;
       src:url(COLONNA.TTF);
     }
	 @font-face
     {
       font-family:Footlight;
       src:url(FTLTLT.TTF);
     }
	 @font-face
     {
       font-family:Book;
       src:url(BKANT.TTF);
     }
   header
     {
       background-color:black;
  	 height:100px;
  	 position:relative;
  	 width:1140px;
  	 margin-left:105px;
  	 color:white;
  	 font-size:16px;
  	 text-align:left;
	 border: 2px solid black;
	 border-radius:7px;
     }
     ul
     {
       text-align:right;
  	   display: inline;
       margin-top:10px;
       padding: 3px 4px 3px 4px;
       list-style: none;
	   font-family:Footlight;
	   font-size:18px;
     }
     ul li
     {
       display: inline-block;
       position: relative;
  	   padding: 6px 8px 6px 8px;
       background:black;
  	   color:white;
     }
     ul li:hover 
     {
       background: orange;
       color: #000000;
     }
     ul li ul
     {
       position:absolute;
  	   top:22px;
       left:0;
       width:100px;
       display:none;
       visibility:hidden;
     }
     ul li ul li
     { 
       background: black;
       display:block; 
       color: white;
     }
     ul li:hover ul
     {
      display: block;
  	  padding-left:0px;
      opacity: 1;
  	  z-index:3;
      visibility: visible;
     }
     .donate
     {
  	 border:1px solid black;
  	 border-radius:2px;
     }
     ul#nav
	 {
		 float:right;
		 color:white;
		 background:black;
		 font-size:20px;
		 margin-top:-50px;
		 padding-top:0px;
	 }
	 ul#nav li
	 {
	   display: inline-block;
       position: relative;
  	   padding: 2px 2px 2px 2px;
       background:black;
  	 }
	 h1
	 {
		 font-family:Colonna;
		 font-size:40px;
	 }
     #logo
     {
       z-index:3;
  	 text-align:left;
  	 position:absolute;
  	 width:80px;
  	 height:80px;
  	 margin-top:10px;
  	 margin-left:50px;
     }   
   #formreg
   {
     padding-left:70px;
	 padding-top:50px;
	 background:black;
	 margin-left:105px;
	 width:1140px;
	 height:566px;
	 margin-top:10px;
	 border: 2px solid black;
	 border-radius:7px;
	 font-family:Book;
	 font-size:18px;
   }
   table,tr,td
   {
     color:white;
	 width:550px;
	 border:0px solid black;
   }
   tr
   {
     height:50px;
   }
   .textbox 
   { 
     background: white; 
     border: 1px double #DDD; 
     border-radius: 5px; 
     box-shadow: 0 0 5px #333; 
     color: #666; 
     outline: none; 
     height:25px; 
     width: 200px; 
   } 
   .button
   {
     background:#9ceded;
	 border: 1px double #DDD; 
     border-radius: 5px; 
     box-shadow: 0 0 5px #333; 
     color: #666; 
     outline: none; 
     height:25px; 
	 width:100px;
   }
   a
	 {
		 color:orange;
	 }
	 a:hover
	 {
		 color:white;
	 }
	 a:visited
	 {
		 color:orange;
	 }
   body
   { 
     background-color:#f2d7ac;
	 position:relative;
   }
  </style>
  <script>
   function myFunc()
   {
     var fname=document.getElementById("fname").value;
     var lname=document.getElementById("lname").value;
	 var phno=document.getElementById("contact").value;
	 var mail=document.getElementById("mail").value;
	 var pwd=document.getElementById("pwd").value.length;
	 var cpwd=document.getElementById("cpwd").value.length;
	 var pass=document.getElementById("pwd").value;
	 var cpass=document.getElementById("cpwd").value;
	 var patt1 = /^[A-Za-z]+$/;
	 var patt2 = /^[0-9]{10}$/;
	 var patt3 = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	 if(patt1.test(fname)==false)
     {
       alert("Enter First Name Properly");
     }
     if(patt1.test(lname)==false)
     {
       alert("Enter Last Name Properly");
     }	 
	 if(patt2.test(phno)==false)
     {
       alert("Enter Phone Number Properly(can only contain digits and there should be 10 digits)");
     }
	 if(patt3.test(mail)==false)
     {
       alert("Enter Email Id Properly");
     }	 
	 if (pwd == 0 || pwd < 8 || pwd > 15)  
     {  
       alert("Password should not be empty / length be between 8 to 15 characters");  
     }
     if (cpwd == 0 || cpwd < 8 || cpwd > 15)  
     {  
       alert("Password should not be empty / length be between 8 to 15 characters");  
     }	
     if (pass != cpass)
     {
       alert("Passwords don't match");
     }	   
   }
  </script>     
 </head>
 <body link="white">
  <header>
   <a href="home.php" >
   <img  id="logo" src="logo.png" />
   </a>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   <ul> 
    <li>About Us
	 <ul>
	  <li><a href="history.html">History</li>
	  <li><a href="work.html">Our Work</li>
	  <li><a href="Contact Us.php">Contact</a></li>
	 </ul>
	</li>
	<li class="donate"><a href="Donate.php" style="color: white">Donate</a></li>
   </ul>
   <h1 align="center" style="color:orange;"><a href="home.php">Indian Wildlife</a></h1>
   <ul id="nav">
    <li><a href="Blog.php">Blog</a></li> &nbsp; &nbsp;
	<li><a href="Gallery.php">Gallery</a></li> &nbsp; &nbsp;
   </ul>
   </header>
  <section id="formreg">
   <form action=" " method="POST"> 
    <table cellpadding="10" cellspacing="100" align="center">
     <tr>
	  <td>Name:</td>
	  <td><input type="text" id="fname" name="fname" class="textbox" placeholder=" First Name" />
	  <td><input type="text" id="lname" name="lname" class="textbox" placeholder=" Last Name" />
	 </tr>
	 
	 <tr>
	  <td>Address:*</td>
	  <td><input type="text" id="add" name="add" class="textbox" placeholder=" Line 1" />
	  <td></td>
	 </tr>
	 	 
	 <tr>
	  <td></td>
	  <td><input type="text" id="ad2" name="ad2" class="textbox" placeholder=" Line 2" />
	 </tr>
	  
	 <tr>
	  <td>City:</td>
	  <td><select id="city" class="textbox" name="city">
	    <option>Bangalore</option>
		<option>Chennai</option>
		<option>New Delhi</option>
		<option>Mumbai</option>
	  </td>
	 </tr>
	 
	 <tr>
	  <td>Gender:</td>
	  <td>
	   <input type="radio" id="male" name="gender" value="male"/> Male
	   &nbsp; &nbsp;
	   <input type="radio" id="female" name="gender" value="female"/> Female  
	  </td>
	 </tr>
	 
	 <tr>
	  <td>Contact Number:</td>
	  <td><input type="number" id="contact" name="contact" class="textbox" placeholder=" Contact Number" /></td>
	 </tr>
	 
	 <tr>
	  <td>E-mail:</td>
	  <td><input type="email" id="mail" name="mail" class="textbox" placeholder=" E-mail id" /></td>
     </tr>
	 
	 <tr>
	  <td>Password:</td>
	  <td><input type="password" id="pwd" name="pwd" class="textbox" placeholder=" Password" /></td>
	 </tr>
	 
	 <tr>
	  <td>Confirm Password:</td>
	  <td><input type="password" id="cpwd" name="cpwd" class="textbox" placeholder=" Confirm Password" /></td>
	 </tr>
	 
	 <tr>
	  <td></td>
	  <td align="right"><input type="submit" value="Submit" class="button" onclick="myFunc()" name="submit"/>
	 </tr>
	  
	</table>
   </form>
   <?php
    if(isset($_POST['submit']))
     {
      $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
      $n1=$_POST['fname'];
      $n2=$_POST['add'];
      $n3=$_POST['city'];
      $n4=$_POST['gender'];
      $n5=$_POST['contact'];
      $n6=$_POST['mail'];
      $n7=$_POST['pwd'];
      $sql=mysql_query("insert into users values(' ','$n1','$n2','$n3','$n4',$n5,'$n6','$n7')");
      echo "<script> alert('You have Successfully Signed Up!'); </script>";
    }
    ?>
  </section>
 </body>
</html> 
<html>
 <head>
  <title>Donate</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
  <style>
a
	 {
		 color:orange;
	 }
	 a:hover
	 {
		 color:white;
	 }
	 a:visited
	 {
		 color:orange;
	 }
@font-face
     {
       font-family:Colonna;
       src:url(COLONNA.TTF);
     }
	 @font-face
     {
       font-family:Footlight;
       src:url(FTLTLT.TTF);
     }
	 @font-face
     {
       font-family:Book;
       src:url(BKANT.TTF);
     }
     header
     {
       background-color:black;
  	 height:100px;
  	 position:relative;
  	 width:1140px;
  	 margin-left:105px;
  	 color:white;
  	 font-size:16px;
  	 text-align:left;
	 border: 2px solid black;
	 border-radius:7px;
     }
	 ul
     {
       text-align:right;
  	   display: inline;
       margin-top:10px;
       padding: 3px 4px 3px 4px;
       list-style: none;
	   font-family:Footlight;
	   font-size:18px;
     }
     ul li
     {
       display: inline-block;
       position: relative;
  	   padding: 6px 8px 6px 8px;
       background:black;
  	   color:white;
     }
     ul li:hover 
     {
       background: orange;
       color: #000000;
     }
     ul li ul
     {
       position:absolute;
  	   top:22px;
       left:0;
       width:100px;
       display:none;
       visibility:hidden;
     }
     ul li ul li
     { 
       background: black;
       display:block; 
       color: white;
     }
     ul li:hover ul
     {
      display: block;
  	  padding-left:0px;
      opacity: 1;
  	  z-index:3;
      visibility: visible;
     }
     .donate
     {
  	 border:1px solid black;
  	 border-radius:2px;
     }
     ul#nav
	 {
		 float:right;
		 color:white;
		 background:black;
		 font-size:20px;
		 margin-top:-50px;
		 padding-top:0px;
	 }
	 ul#nav li
	 {
	   display: inline-block;
       position: relative;
  	   padding: 2px 2px 2px 2px;
       background:black;
  	 }
	 h1
	 {
		 font-family:Colonna;
		 font-size:40px;
	 }
     #logo
     {
       z-index:3;
       text-align:left;
       position:absolute;
  	   width:80px;
  	   height:80px;
  	   margin-top:10px;
  	   margin-left:50px;
     } 
     body
     { 
       background-color:#f2d7ac;
  	 position:relative;
     }
  
  #demo1
  {
    text-align:center;
  }
  #demo2
  {
    color:blue;
  }
  .intro
  {
    border-radius:5px;
    padding:10px;
    margin:5px;
    width:300px;
  }
 </style>
 <script>
   function myfunc()
   {
     var fname = document.getElementById("fname").value;
     var lname = document.getElementById("lname").value;
     var phno = document.getElementById("phno").value;
     var patt1 = /^[A-Za-z]+$/;
     if(patt1.test(fname)==false)
     { 
       alert("Enter First Name Properly");
     }
     if(patt1.test(lname)==false)
     {
       alert("Enter Last Name Properly");
     }
     var patt2 = /^[0-9]{10,11}$/
     if(patt2.test(phno)==false)
     {
       alert("Enter Phone Number Properly");
     }
   }
  </script>
 </head>
 <body>
<header>
   <a href="home.php" >
   <img  id="logo" src="logo.png" />
   </a>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   <ul> 
    <li>About Us
	 <ul>
	  <li><a href="history.html">History</li>
	  <li><a href="work.html">Our Work</li>
	  <li><a href="Contact Us.php">Contact</a></li>
	 </ul>
	</li>
	<li class="donate"><a href="Donate.php" style="color: white">Donate</a></li>
   </ul>
   <h1 align="center" style="color:orange;"><a href="home.php">Indian Wildlife</a></h1>
   <ul id="nav">
    <li><a href="Blog.php">Blog</a></li> &nbsp; &nbsp;
	<li><a href="Gallery.php">Gallery</a></li> &nbsp; &nbsp;
   </ul>
   </header>
  <div id="demo1">
  <br />
  <br />
   <form action=" " method="POST">
     
 <input class="intro" type="text" name="fname" placeholder="First Name" id="fname" required><br>
    <input class="intro" type="text" name="lname" placeholder="Last Name" id="lname" required><br>
    <input class="intro" type="number" name="phno" placeholder="Phone Number" id="phno" required><br>
    <input class="intro" type="email" name="em" placeholder="E-mail Address" id="em" required><br>
    <input class="intro" type="number" name="amt" placeholder="Amount" id="amt" required><br>
    <input class="intro" type="username" name="un" placeholder="Username" id="un" required><br>
    <input class="intro" type="password" name="pwd" placeholder="Password" id="pwd" required><br>
    <input class="intro" type="submit" name="submit" onclick="myfunc()" value="Continue">
   </form>
  <?php
   if(isset($_POST['submit']))
     {
      $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
      $n1=$_POST['fname'];
      $n2=$_POST['phno'];
      $n3=$_POST['em'];
      $n4=$_POST['amt'];
      $n5=$_POST['un'];
      $n6=$_POST['pwd'];
      $count=0;
      $sql="select * from users where Email='$n3' and Password='$n6'";
      $res=mysql_query($sql);
      while($row=mysql_fetch_array($res))
      {
        $count++;
      } 
      if($count==1)
      {
       $sql=mysql_query("insert into donation values(' ','$n1',$n2,'$n3',$n4,'$n5','$n6')");
       echo "<script> alert('Thank You for your donation!'); </script>";
      }
      else
      {
        echo "<script> alert('Incorrect Login credentials!'); </script>";
     }
    }
  ?>
</div>
 </body>
</html>
<html>
 <head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <style>
   @font-face
     {
       font-family:Colonna;
       src:url(COLONNA.TTF);
     }
	 @font-face
     {
       font-family:Footlight;
       src:url(FTLTLT.TTF);
     }
	 @font-face
     {
       font-family:Book;
       src:url(BKANT.TTF);
     }
     header
     {
       background-color:black;
  	 height:100px;
  	 position:relative;
  	 width:1140px;
  	 margin-left:105px;
  	 color:white;
  	 font-size:16px;
  	 text-align:left;
	 border: 2px solid black;
	 border-radius:7px;
     }
	 ul
     {
       text-align:right;
  	   display: inline;
       margin-top:10px;
       padding: 3px 4px 3px 4px;
       list-style: none;
	   font-family:Footlight;
	   font-size:18px;
     }
     ul li
     {
       display: inline-block;
       position: relative;
  	   padding: 6px 8px 6px 8px;
       background:black;
  	   color:white;
     }
     ul li:hover 
     {
       background: orange;
       color: #000000;
     }
     ul li ul
     {
       position:absolute;
  	   top:22px;
       left:0;
       width:100px;
       display:none;
       visibility:hidden;
     }
     ul li ul li
     { 
       background: black;
       display:block; 
       color: white;
     }
     ul li:hover ul
     {
      display: block;
  	  padding-left:0px;
      opacity: 1;
  	  z-index:3;
      visibility: visible;
     }
     .donate
     {
  	 border:1px solid black;
  	 border-radius:2px;
     }
     ul#nav
	 {
		 float:right;
		 color:white;
		 background:black;
		 font-size:20px;
		 margin-top:-50px;
		 padding-top:0px;
	 }
	 ul#nav li
	 {
	   display: inline-block;
       position: relative;
  	   padding: 2px 2px 2px 2px;
       background:black;
  	 }
	 h1
	 {
		 font-family:Colonna;
		 font-size:40px;
	 }
     #logo
     {
       z-index:3;
       text-align:left;
       position:absolute;
  	   width:80px;
  	   height:80px;
  	   margin-top:10px;
  	   margin-left:50px;
     }      
   #post
   {
     background-color:black;
	 width:1140px;
	 margin-left:105px;
	 margin-top:1px;
	 padding-bottom:5px;
	 text-align:center;
	 font-family:Book;
	 font-size:18px;
   }
    a
	 {
		 color:orange;
	 }
	 a:hover
	 {
		 color:white;
	 }
	 a:visited
	 {
		 color:orange;
	 }
   table,tr,td
   {
     color:white;
	 padding-top:10px;
	 padding-bottom:10px;
	 padding-left:10px;
	 padding-right:10px;
	 width:500px;
	 border: 1px solid black;
	 font-family:Book;
	 font-size:18px;
   }
   td
   {
     width:100px;
   }
   .textbox 
   { 
     background: white; 
     border: 1px double #DDD; 
     border-radius: 5px; 
     box-shadow: 0 0 5px #333; 
     color: #666; 
     outline: none; 
     height:25px; 
     width: 300px; 
   } 
   .textarea
   {
     background: white; 
     border: 1px double #DDD; 
     border-radius: 5px; 
     box-shadow: 0 0 5px #333; 
     color: #666; 
     outline: none; 
   } 
   .button
   {
     background:#9ceded;
	 border: 1px double #DDD; 
     border-radius: 5px; 
     box-shadow: 0 0 5px #333; 
     color: #666; 
     outline: none; 
     height:25px; 
	 width:100px;
   }
body
     { 
       background-color:#f2d7ac;
  	 position:relative;
     }
  </style>
 </head>
 <body>
  <header>
   <a href="home.php" >
   <img  id="logo" src="logo.png" />
   </a>
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
   <ul> 
    <li>About Us
	 <ul>
	  <li><a href="history.html">History</li>
	  <li><a href="work.html">Our Work</li>
	  <li><a href="Contact Us.php">Contact</a></li>
	 </ul>
	</li>
	<li class="donate"><a href="Donate.php" style="color: white">Donate</a></li>
   </ul>
   <h1 align="center" style="color:orange;"><a href="home.php">Indian Wildlife</a></h1>
   <ul id="nav">
    <li><a href="Blog.php">Blog</a></li> &nbsp; &nbsp;
	<li><a href="Gallery.php">Gallery</a></li> &nbsp; &nbsp;
   </ul>
   </header>
 <center><h3> Login  </h3><br>
  <form name='login' action='' method='POST'>
  <p>
  Username: &nbsp;
  <input type='email'  name='username' size='14' style='color:black' class='login'/>
  <br /><br />
  Password: &nbsp;&nbsp;
  <input name='password' type='password' size='14' class='login' style='color:black'/>
  <br /><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type='submit' name='submit' value='Login'/>
  </form> </center>
     <?php 
     
     $conn=mysql_connect("localhost","root","");
      mysql_select_db("wildlife",$conn);
     if(isset($_POST['submit']))
     {
      $u=$_POST['username'];
      $p=$_POST['password'];
      $count=0; 
      $sql="select * from users where Email='$u' and Password='$p'";
      $res=mysql_query($sql);
      while($row=mysql_fetch_array($res))
      {
        $count++;
      } 
      if($count==1)
      {
        echo "<script> alert('Succesfull Login!'); </script>";
        echo '<META HTTP-EQUIV="Refresh" content="5; URL=acblog2.php">';
      }
      if($count!=1)
      {
        echo "<script> alert('Incorect details!'); </script>";
      }
    }
    ?>
  </body>
  </html>